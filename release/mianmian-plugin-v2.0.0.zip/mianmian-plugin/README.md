# 眠眠 2.0（Mianmian）— 面向 Windows + DSH 的省 Token 1v1 私聊伴侣插件

融合 **`surfcore` 1v1 精简版** 与 **`dsh-world` 核心设计**：
- **仅 1v1 QQ 私聊**：入口硬锁唯一 `ownerQQ`，彻底移除群聊、桌宠、B站与本地语音包。
- **三层省钱记忆**：`我是谁.md` + 固定 11 词 `mood.md` + `叙事衰减记忆卡` + `SQLite 全量归档/只读历史日记/相册` + `memory_find/read` 按需翻旧账。
- **省 Token 80% 核心设计**：
  1. 从 39+ 工具缩减为 **6 个大脑决策型工具**（`memory_find` / `memory_read` / `set_mood` / `plan_next` / `write_diary` / `save_photo`），日常私聊 **1 轮直出**；
  2. **前静后动 Prompt 排布**（工具与人设放最前吃 1 折 Prefix Cache，实时时间与心情放尾部）；
  3. 剥离工具调用的 **`toolFree` 对话压缩**，将单次上下文控制在低水位；
  4. **错峰低谷整理**：凌晨自动执行叙事卡衰减与整理。
- **纯在线语音**：仅留云端 TTS HTTP 接口，带 120 字与每分钟 2 条频控。

## 快速上传到你的 GitHub 仓库 (`https://github.com/BUYA778/-`)

```powershell
git init
git add .
git commit -m "init: mianmian 2.0 windows dsh plugin"
git branch -M main
git remote add origin https://github.com/BUYA778/-.git
git push -u origin main
```

## Windows + DSH 本地安装

详见 [INSTALL.md](INSTALL.md)。
